// await TestActions.tap(ASCHomeScreenTestKeys.getColor(0, 3));
// await Screenshot.screenshot("ASC-Home-Screen-1");
// await TestActions.scroll(
//   scroller: ASCHomeScreenTestKeys.rootScroll,
//   x: -width,
// );
// await TestActions.delay(8000);
// await TestActions.tap(ASCHomeScreenTestKeys.getColor(1, 1));
// await TestActions.tap(ASCHomeScreenTestKeys.getSize(1, 2));
// await Screenshot.screenshot("ASC-Home-Screen-2");
// await TestActions.scroll(
//   scroller: ASCHomeScreenTestKeys.rootScroll,
//   x: -width,
// );
// await TestActions.tap(ASCHomeScreenTestKeys.getColor(2, 4));
// await TestActions.tap(ASCHomeScreenTestKeys.getSize(2, 2));
// await Screenshot.screenshot("ASC-Home-Screen-3");
