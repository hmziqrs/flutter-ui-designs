// await Screenshot.screenshot("SKV-Home-Screen-1");
// await driver.scrollUntilVisible(
//   find.byValueKey(SKVHomeScreenTestKeys.planetsScroll),
//   find.byValueKey(SKVRootTestKeys.jupiter),
//   dxScroll: -160,
//   dyScroll: 0.0,
//   timeout: Duration(seconds: 30),
// );
// await Screenshot.screenshot("SKV-Home-Screen-2");
// await driver.scrollUntilVisible(
//   find.byValueKey(SKVHomeScreenTestKeys.rootScroll),
//   find.byValueKey(SKVRootTestKeys.story6),
//   dxScroll: 0.0,
//   dyScroll: -200.0,
//   timeout: Duration(seconds: 30),
// );
// await Screenshot.screenshot("SKV-Home-Screen-3");
// await driver.scroll(
//   find.byValueKey(SKVHomeScreenTestKeys.rootScroll),
//   0.0,
//   2000.0,
//   Duration(milliseconds: 400),
// );
// TestActions.delay(2000);

// // Mini App SKV Detail Screen
// await TestActions.tap(SKVRootTestKeys.jupiter);
// await Screenshot.screenshot("SKV-Detail-Screen-1", pre: 1000);
// await driver.scroll(
//   find.byValueKey(SKVDetailScreenTestKeys.rootScroll),
//   width,
//   0.0,
//   Duration(milliseconds: 400),
// );
// await Screenshot.screenshot("SKV-Detail-Screen-2");
// await driver.scroll(
//   find.byValueKey(SKVDetailScreenTestKeys.rootScroll),
//   width,
//   0.0,
//   Duration(milliseconds: 400),
// );
// await Screenshot.screenshot("SKV-Detail-Screen-3");
