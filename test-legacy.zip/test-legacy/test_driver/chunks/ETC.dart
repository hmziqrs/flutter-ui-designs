// await Screenshot.screenshot("ETC-Home-Screen-1");
// await driver.scroll(
//   find.byValueKey(ETCHomeScreenTestKeys.radiusBase),
//   -100.0,
//   0.0,
//   Duration(milliseconds: 400),
// );
// await Screenshot.screenshot("ETC-Home-Screen-2");
// await TestActions.tap(ETCHomeScreenTestKeys.playPauseBtn);
// await Screenshot.screenshot("ETC-Home-Screen-3");
// await TestActions.tap(ETCHomeScreenTestKeys.resetBtn);
// await Screenshot.screenshot("ETC-Home-Screen-4");
